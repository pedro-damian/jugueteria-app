function BannerCotiza() {
  return (
    <div className="bg-green-500 text-white text-center py-2 text-sm">
      Cotiza tu envío a nuestro Whatsapp - 987654321 - mundomagico@gmail.com
    </div>
  );
}

export default BannerCotiza;

export const brands = [
  {
    id: 1,
    name: "Playskool",
    image: "/src/assets/brands/hasbro-logo.png",
  },
  {
    id: 2,
    name: "LEGO",
    image: "/src/assets/brands/lego-logo.png",
  },
  {
    id: 3,
    name: "Bandai",
    image: "/src/assets/brands/bandai-logo.png",
  },
  {
    id: 4,
    name: "Barbie",
    image: "/src/assets/brands/barbie-logo.png",
  },
  {
    id: 5,
    name: "Hot Wheels",
    image: "/src/assets/brands/hot-wheels-logo.png",
  },
  {
    id: 6,
    name: "UNO",
    image: "/src/assets/brands/marvel-logo.png",
  },
  {
    id: 7,
    name: "UNO",
    image: "/src/assets/brands/playskool-logo.png",
  },
];

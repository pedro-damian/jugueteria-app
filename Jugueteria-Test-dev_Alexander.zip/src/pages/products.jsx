export const products = [
  { id: 1, name: "Juego de Mesa - Monopoly Clásico", price: 74.9, image: "/images/monopoly.jpg", brand: "HASBRO", code: "1234" },
  { id: 2, name: "Figura de Acción - Goku", price: 120.0, image: "/images/goku.jpg", brand: "Bandai", code: "5678" },
];
